#include <stdio.h>

int x = 1;

int main() {
	int counter;
	for (counter = 0; x != 0; ++counter)
		x <<= 1;
	printf("Número de bits do tipo \"int\" %d\n", counter);
}
