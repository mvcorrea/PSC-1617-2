#include <stdio.h>
#include <string.h>

/* #define EOF	-1 */

int readline(char buffer[], int size_buffer) {
	int i = 0;
	char c = getchar();
	while (i < size_buffer && c != '\n' && c != EOF) {
		buffer[i++] = c;
		c = getchar();
	}
	buffer[i] = 0;
	return c != EOF ? i : EOF;
}

void copy(char dst[], char src[]){
	int i;
	for (i = 0; src[i] != 0; ++i)
		dst[i] = src[i];
	dst[i] = 0;
}


char longest_line[1000], line[1000];
int longest_size;

int main() {
	int line_size = readline(line, sizeof(line));
	while (line_size != EOF) {
		if (line_size > longest_size) {
			longest_size = line_size;
			copy(longest_line, line);
		}
		line_size = readline(line, sizeof(line));
	}
	printf("Longest line = %s\n", longest_line);
}
