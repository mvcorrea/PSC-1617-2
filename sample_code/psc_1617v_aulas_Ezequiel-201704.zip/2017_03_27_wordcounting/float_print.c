#include <stdio.h>

float x = 3.5;

void *pv = &x;

int main() {
	int *pi = pv;
	printf("%x\n", *pi);
}
