#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <errno.h>

/*-----------------------------------------------------------------------------
 
 */
char *separadores = " .,;!?\t\n\f:-\"\'\\/(){}[]*=%#<>";

char *word_read(FILE *fd){
	static char buffer[100];
	int i = 0, c;
	do {
		c = fgetc(fd);
		if(c == EOF){
			return NULL;
		}
	}
	while (strchr(separadores, c) != NULL);
	do {
		buffer[i++] = c;
		c = fgetc(fd);
		if(c == EOF)
			break;
	} while (strchr(separadores, c) == NULL);
	buffer[i] = '\0';
	return buffer;
}

/*-----------------------------------------------------------------------------
 */
#define WORD_MAX_SIZE	100
#define WORDS_MAX		100000

typedef struct {
	char text[WORD_MAX_SIZE];
	int counter;
} Word;

Word words[WORDS_MAX];
int words_count;

void word_insert(char *word) {
	int i;
	for (i = 0; i < words_count; ++i) {
		if (strcmp(words[i].text, word) == 0) {
			words[i].counter++;
			break;
		}
	}
	if (i == words_count) {
		strcpy(words[words_count++].text, word);
		words[i].counter = 1;
	}
}

void word_print(int n) {
	for (int i = 0; i < n; ++i)
		printf("%s - %d\n", words[i].text, words[i].counter);
}

void sort() {
	for (int i = 0; i < words_count - 1; ++i)
		for (int j = 0; j < words_count - i - 1; ++j)
			if (words[j].counter < words[j + 1].counter) {
				Word tmp = words[j];
				words[j] = words[j + 1];
				words[j + 1] = tmp;
			}
}

/*-----------------------------------------------------------------------------
 */
unsigned int get_time() {
	struct timespec ts;
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return ts.tv_sec * 1000 + (ts.tv_nsec / 1000000);
}

int main(int argc, char *argv[]) {
	FILE *fd = fopen(argv[1], "r");
	if (fd == NULL) {
		fprintf(stderr, "Error:%s\n", strerror(errno));
		return -1;
	}
	unsigned initial = get_time();
	printf("ler palavras\n");
	char *word = word_read(fd);
	while (word != NULL) {
		word_insert(word);
		word = word_read(fd);
	}
	printf("Palavras = %d, duração = %d ms\n", words_count, get_time() - initial);
	fclose(fd);
	initial = get_time();
	sort();
	printf("Duração da ordenação - %d ms\n", get_time() - initial);
	word_print(10);

}
