int a = 10, b = 20, c;

void addp(int *op1, int *op2, int *res);

int main() {
	addp(&a, &b, &c);
}

int add(int a, int b) {
	return a + b;
}
