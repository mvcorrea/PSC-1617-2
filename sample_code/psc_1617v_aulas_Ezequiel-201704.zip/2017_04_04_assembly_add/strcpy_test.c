void my_strcpy(char *dst, char *src);

char d[100] = "aaa";

int main() {
	my_strcpy("string de teste", d);
}
